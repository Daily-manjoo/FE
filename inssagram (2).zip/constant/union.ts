export const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;
